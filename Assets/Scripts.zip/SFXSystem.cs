public class SFXSystem : SoundSystem
{
    
}
